import { useState } from "react";
import Header from "./components/Header";
import RepoList from "./components/RepoList";
import UserProfile from "./components/UserProfile";
import type { GithubRepo, GithubUser } from "./types/github";
import { fetchRepo, fetchUser } from "./api/github";

function App() {
  const [user, setUser] = useState<GithubUser>();
  const [repos, setRepos] = useState<GithubRepo[]>();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<String | null>(null);

  async function searchUser(username: string) {
    setLoading(true);

    try {
      const user = await fetchUser(username);
      setUser(user);
      const res = await fetchRepo(user!.login);
      setRepos(res);
    } catch (err) {
      setError("An Error Accured!");
      setUser(undefined);
      setRepos(undefined);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-full">
      <Header search={searchUser} />

      <main className="p-10">
        {loading ? (
          <p className="text-center text-[#8b949e] font-bold text-xl bg-[#161b22] border border-[#30363d] py-10 rounded">
            Loading...
          </p>
        ) : (
          <>
            {error ? (
              <p className="text-center text-[#8b949e] font-bold text-xl bg-[#161b22] border border-[#30363d] py-10 rounded">
                {error}
              </p>
            ) : (
              <>
                {!user && (
                  <p className="text-center text-[#8b949e] font-bold text-xl bg-[#161b22] border border-[#30363d] py-10 rounded">
                    Search Github User!
                  </p>
                )}
                {user && repos && (
                  <>
                    <UserProfile user={user} />
                    <RepoList repos={repos} />
                  </>
                )}
              </>
            )}
          </>
        )}
      </main>
    </div>
  );
}

export default App;
